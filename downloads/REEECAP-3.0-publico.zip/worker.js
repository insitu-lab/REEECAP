/* REEECAP — leitor local de ZIPs/JSONs. Nenhum dado pessoal é enviado à rede.
   Incorpora pako 0.2.9 (nodeca/pako), distribuído sob licença MIT. */

'use strict';
/* pako 0.2.9 nodeca/pako */
!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var t;t="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:this,t.pako=e()}}(function(){return function e(t,i,n){function a(o,s){if(!i[o]){if(!t[o]){var f="function"==typeof require&&require;if(!s&&f)return f(o,!0);if(r)return r(o,!0);var l=new Error("Cannot find module '"+o+"'");throw l.code="MODULE_NOT_FOUND",l}var d=i[o]={exports:{}};t[o][0].call(d.exports,function(e){var i=t[o][1][e];return a(i?i:e)},d,d.exports,e,t,i,n)}return i[o].exports}for(var r="function"==typeof require&&require,o=0;o<n.length;o++)a(n[o]);return a}({1:[function(e,t,i){"use strict";var n="undefined"!=typeof Uint8Array&&"undefined"!=typeof Uint16Array&&"undefined"!=typeof Int32Array;i.assign=function(e){for(var t=Array.prototype.slice.call(arguments,1);t.length;){var i=t.shift();if(i){if("object"!=typeof i)throw new TypeError(i+"must be non-object");for(var n in i)i.hasOwnProperty(n)&&(e[n]=i[n])}}return e},i.shrinkBuf=function(e,t){return e.length===t?e:e.subarray?e.subarray(0,t):(e.length=t,e)};var a={arraySet:function(e,t,i,n,a){if(t.subarray&&e.subarray)return void e.set(t.subarray(i,i+n),a);for(var r=0;r<n;r++)e[a+r]=t[i+r]},flattenChunks:function(e){var t,i,n,a,r,o;for(n=0,t=0,i=e.length;t<i;t++)n+=e[t].length;for(o=new Uint8Array(n),a=0,t=0,i=e.length;t<i;t++)r=e[t],o.set(r,a),a+=r.length;return o}},r={arraySet:function(e,t,i,n,a){for(var r=0;r<n;r++)e[a+r]=t[i+r]},flattenChunks:function(e){return[].concat.apply([],e)}};i.setTyped=function(e){e?(i.Buf8=Uint8Array,i.Buf16=Uint16Array,i.Buf32=Int32Array,i.assign(i,a)):(i.Buf8=Array,i.Buf16=Array,i.Buf32=Array,i.assign(i,r))},i.setTyped(n)},{}],2:[function(e,t,i){"use strict";function n(e,t){if(t<65537&&(e.subarray&&o||!e.subarray&&r))return String.fromCharCode.apply(null,a.shrinkBuf(e,t));for(var i="",n=0;n<t;n++)i+=String.fromCharCode(e[n]);return i}var a=e("./common"),r=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch(e){r=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch(e){o=!1}for(var s=new a.Buf8(256),f=0;f<256;f++)s[f]=f>=252?6:f>=248?5:f>=240?4:f>=224?3:f>=192?2:1;s[254]=s[254]=1,i.string2buf=function(e){var t,i,n,r,o,s=e.length,f=0;for(r=0;r<s;r++)i=e.charCodeAt(r),55296===(64512&i)&&r+1<s&&(n=e.charCodeAt(r+1),56320===(64512&n)&&(i=65536+(i-55296<<10)+(n-56320),r++)),f+=i<128?1:i<2048?2:i<65536?3:4;for(t=new a.Buf8(f),o=0,r=0;o<f;r++)i=e.charCodeAt(r),55296===(64512&i)&&r+1<s&&(n=e.charCodeAt(r+1),56320===(64512&n)&&(i=65536+(i-55296<<10)+(n-56320),r++)),i<128?t[o++]=i:i<2048?(t[o++]=192|i>>>6,t[o++]=128|63&i):i<65536?(t[o++]=224|i>>>12,t[o++]=128|i>>>6&63,t[o++]=128|63&i):(t[o++]=240|i>>>18,t[o++]=128|i>>>12&63,t[o++]=128|i>>>6&63,t[o++]=128|63&i);return t},i.buf2binstring=function(e){return n(e,e.length)},i.binstring2buf=function(e){for(var t=new a.Buf8(e.length),i=0,n=t.length;i<n;i++)t[i]=e.charCodeAt(i);return t},i.buf2string=function(e,t){var i,a,r,o,f=t||e.length,l=new Array(2*f);for(a=0,i=0;i<f;)if(r=e[i++],r<128)l[a++]=r;else if(o=s[r],o>4)l[a++]=65533,i+=o-1;else{for(r&=2===o?31:3===o?15:7;o>1&&i<f;)r=r<<6|63&e[i++],o--;o>1?l[a++]=65533:r<65536?l[a++]=r:(r-=65536,l[a++]=55296|r>>10&1023,l[a++]=56320|1023&r)}return n(l,a)},i.utf8border=function(e,t){var i;for(t=t||e.length,t>e.length&&(t=e.length),i=t-1;i>=0&&128===(192&e[i]);)i--;return i<0?t:0===i?t:i+s[e[i]]>t?i:t}},{"./common":1}],3:[function(e,t,i){"use strict";function n(e,t,i,n){for(var a=65535&e|0,r=e>>>16&65535|0,o=0;0!==i;){o=i>2e3?2e3:i,i-=o;do a=a+t[n++]|0,r=r+a|0;while(--o);a%=65521,r%=65521}return a|r<<16|0}t.exports=n},{}],4:[function(e,t,i){"use strict";t.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],5:[function(e,t,i){"use strict";function n(){for(var e,t=[],i=0;i<256;i++){e=i;for(var n=0;n<8;n++)e=1&e?3988292384^e>>>1:e>>>1;t[i]=e}return t}function a(e,t,i,n){var a=r,o=n+i;e^=-1;for(var s=n;s<o;s++)e=e>>>8^a[255&(e^t[s])];return e^-1}var r=n();t.exports=a},{}],6:[function(e,t,i){"use strict";function n(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}t.exports=n},{}],7:[function(e,t,i){"use strict";var n=30,a=12;t.exports=function(e,t){var i,r,o,s,f,l,d,u,c,h,b,w,m,k,_,g,v,p,x,y,S,E,B,Z,A;i=e.state,r=e.next_in,Z=e.input,o=r+(e.avail_in-5),s=e.next_out,A=e.output,f=s-(t-e.avail_out),l=s+(e.avail_out-257),d=i.dmax,u=i.wsize,c=i.whave,h=i.wnext,b=i.window,w=i.hold,m=i.bits,k=i.lencode,_=i.distcode,g=(1<<i.lenbits)-1,v=(1<<i.distbits)-1;e:do{m<15&&(w+=Z[r++]<<m,m+=8,w+=Z[r++]<<m,m+=8),p=k[w&g];t:for(;;){if(x=p>>>24,w>>>=x,m-=x,x=p>>>16&255,0===x)A[s++]=65535&p;else{if(!(16&x)){if(0===(64&x)){p=k[(65535&p)+(w&(1<<x)-1)];continue t}if(32&x){i.mode=a;break e}e.msg="invalid literal/length code",i.mode=n;break e}y=65535&p,x&=15,x&&(m<x&&(w+=Z[r++]<<m,m+=8),y+=w&(1<<x)-1,w>>>=x,m-=x),m<15&&(w+=Z[r++]<<m,m+=8,w+=Z[r++]<<m,m+=8),p=_[w&v];i:for(;;){if(x=p>>>24,w>>>=x,m-=x,x=p>>>16&255,!(16&x)){if(0===(64&x)){p=_[(65535&p)+(w&(1<<x)-1)];continue i}e.msg="invalid distance code",i.mode=n;break e}if(S=65535&p,x&=15,m<x&&(w+=Z[r++]<<m,m+=8,m<x&&(w+=Z[r++]<<m,m+=8)),S+=w&(1<<x)-1,S>d){e.msg="invalid distance too far back",i.mode=n;break e}if(w>>>=x,m-=x,x=s-f,S>x){if(x=S-x,x>c&&i.sane){e.msg="invalid distance too far back",i.mode=n;break e}if(E=0,B=b,0===h){if(E+=u-x,x<y){y-=x;do A[s++]=b[E++];while(--x);E=s-S,B=A}}else if(h<x){if(E+=u+h-x,x-=h,x<y){y-=x;do A[s++]=b[E++];while(--x);if(E=0,h<y){x=h,y-=x;do A[s++]=b[E++];while(--x);E=s-S,B=A}}}else if(E+=h-x,x<y){y-=x;do A[s++]=b[E++];while(--x);E=s-S,B=A}for(;y>2;)A[s++]=B[E++],A[s++]=B[E++],A[s++]=B[E++],y-=3;y&&(A[s++]=B[E++],y>1&&(A[s++]=B[E++]))}else{E=s-S;do A[s++]=A[E++],A[s++]=A[E++],A[s++]=A[E++],y-=3;while(y>2);y&&(A[s++]=A[E++],y>1&&(A[s++]=A[E++]))}break}}break}}while(r<o&&s<l);y=m>>3,r-=y,m-=y<<3,w&=(1<<m)-1,e.next_in=r,e.next_out=s,e.avail_in=r<o?5+(o-r):5-(r-o),e.avail_out=s<l?257+(l-s):257-(s-l),i.hold=w,i.bits=m}},{}],8:[function(e,t,i){"use strict";function n(e){return(e>>>24&255)+(e>>>8&65280)+((65280&e)<<8)+((255&e)<<24)}function a(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new _.Buf16(320),this.work=new _.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function r(e){var t;return e&&e.state?(t=e.state,e.total_in=e.total_out=t.total=0,e.msg="",t.wrap&&(e.adler=1&t.wrap),t.mode=D,t.last=0,t.havedict=0,t.dmax=32768,t.head=null,t.hold=0,t.bits=0,t.lencode=t.lendyn=new _.Buf32(we),t.distcode=t.distdyn=new _.Buf32(me),t.sane=1,t.back=-1,z):C}function o(e){var t;return e&&e.state?(t=e.state,t.wsize=0,t.whave=0,t.wnext=0,r(e)):C}function s(e,t){var i,n;return e&&e.state?(n=e.state,t<0?(i=0,t=-t):(i=(t>>4)+1,t<48&&(t&=15)),t&&(t<8||t>15)?C:(null!==n.window&&n.wbits!==t&&(n.window=null),n.wrap=i,n.wbits=t,o(e))):C}function f(e,t){var i,n;return e?(n=new a,e.state=n,n.window=null,i=s(e,t),i!==z&&(e.state=null),i):C}function l(e){return f(e,_e)}function d(e){if(ge){var t;for(m=new _.Buf32(512),k=new _.Buf32(32),t=0;t<144;)e.lens[t++]=8;for(;t<256;)e.lens[t++]=9;for(;t<280;)e.lens[t++]=7;for(;t<288;)e.lens[t++]=8;for(x(S,e.lens,0,288,m,0,e.work,{bits:9}),t=0;t<32;)e.lens[t++]=5;x(E,e.lens,0,32,k,0,e.work,{bits:5}),ge=!1}e.lencode=m,e.lenbits=9,e.distcode=k,e.distbits=5}function u(e,t,i,n){var a,r=e.state;return null===r.window&&(r.wsize=1<<r.wbits,r.wnext=0,r.whave=0,r.window=new _.Buf8(r.wsize)),n>=r.wsize?(_.arraySet(r.window,t,i-r.wsize,r.wsize,0),r.wnext=0,r.whave=r.wsize):(a=r.wsize-r.wnext,a>n&&(a=n),_.arraySet(r.window,t,i-n,a,r.wnext),n-=a,n?(_.arraySet(r.window,t,i-n,n,0),r.wnext=n,r.whave=r.wsize):(r.wnext+=a,r.wnext===r.wsize&&(r.wnext=0),r.whave<r.wsize&&(r.whave+=a))),0}function c(e,t){var i,a,r,o,s,f,l,c,h,b,w,m,k,we,me,ke,_e,ge,ve,pe,xe,ye,Se,Ee,Be=0,Ze=new _.Buf8(4),Ae=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!e||!e.state||!e.output||!e.input&&0!==e.avail_in)return C;i=e.state,i.mode===X&&(i.mode=W),s=e.next_out,r=e.output,l=e.avail_out,o=e.next_in,a=e.input,f=e.avail_in,c=i.hold,h=i.bits,b=f,w=l,ye=z;e:for(;;)switch(i.mode){case D:if(0===i.wrap){i.mode=W;break}for(;h<16;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(2&i.wrap&&35615===c){i.check=0,Ze[0]=255&c,Ze[1]=c>>>8&255,i.check=v(i.check,Ze,2,0),c=0,h=0,i.mode=F;break}if(i.flags=0,i.head&&(i.head.done=!1),!(1&i.wrap)||(((255&c)<<8)+(c>>8))%31){e.msg="incorrect header check",i.mode=ce;break}if((15&c)!==U){e.msg="unknown compression method",i.mode=ce;break}if(c>>>=4,h-=4,xe=(15&c)+8,0===i.wbits)i.wbits=xe;else if(xe>i.wbits){e.msg="invalid window size",i.mode=ce;break}i.dmax=1<<xe,e.adler=i.check=1,i.mode=512&c?q:X,c=0,h=0;break;case F:for(;h<16;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(i.flags=c,(255&i.flags)!==U){e.msg="unknown compression method",i.mode=ce;break}if(57344&i.flags){e.msg="unknown header flags set",i.mode=ce;break}i.head&&(i.head.text=c>>8&1),512&i.flags&&(Ze[0]=255&c,Ze[1]=c>>>8&255,i.check=v(i.check,Ze,2,0)),c=0,h=0,i.mode=L;case L:for(;h<32;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}i.head&&(i.head.time=c),512&i.flags&&(Ze[0]=255&c,Ze[1]=c>>>8&255,Ze[2]=c>>>16&255,Ze[3]=c>>>24&255,i.check=v(i.check,Ze,4,0)),c=0,h=0,i.mode=H;case H:for(;h<16;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}i.head&&(i.head.xflags=255&c,i.head.os=c>>8),512&i.flags&&(Ze[0]=255&c,Ze[1]=c>>>8&255,i.check=v(i.check,Ze,2,0)),c=0,h=0,i.mode=M;case M:if(1024&i.flags){for(;h<16;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}i.length=c,i.head&&(i.head.extra_len=c),512&i.flags&&(Ze[0]=255&c,Ze[1]=c>>>8&255,i.check=v(i.check,Ze,2,0)),c=0,h=0}else i.head&&(i.head.extra=null);i.mode=j;case j:if(1024&i.flags&&(m=i.length,m>f&&(m=f),m&&(i.head&&(xe=i.head.extra_len-i.length,i.head.extra||(i.head.extra=new Array(i.head.extra_len)),_.arraySet(i.head.extra,a,o,m,xe)),512&i.flags&&(i.check=v(i.check,a,m,o)),f-=m,o+=m,i.length-=m),i.length))break e;i.length=0,i.mode=K;case K:if(2048&i.flags){if(0===f)break e;m=0;do xe=a[o+m++],i.head&&xe&&i.length<65536&&(i.head.name+=String.fromCharCode(xe));while(xe&&m<f);if(512&i.flags&&(i.check=v(i.check,a,m,o)),f-=m,o+=m,xe)break e}else i.head&&(i.head.name=null);i.length=0,i.mode=P;case P:if(4096&i.flags){if(0===f)break e;m=0;do xe=a[o+m++],i.head&&xe&&i.length<65536&&(i.head.comment+=String.fromCharCode(xe));while(xe&&m<f);if(512&i.flags&&(i.check=v(i.check,a,m,o)),f-=m,o+=m,xe)break e}else i.head&&(i.head.comment=null);i.mode=Y;case Y:if(512&i.flags){for(;h<16;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(c!==(65535&i.check)){e.msg="header crc mismatch",i.mode=ce;break}c=0,h=0}i.head&&(i.head.hcrc=i.flags>>9&1,i.head.done=!0),e.adler=i.check=0,i.mode=X;break;case q:for(;h<32;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}e.adler=i.check=n(c),c=0,h=0,i.mode=G;case G:if(0===i.havedict)return e.next_out=s,e.avail_out=l,e.next_in=o,e.avail_in=f,i.hold=c,i.bits=h,N;e.adler=i.check=1,i.mode=X;case X:if(t===Z||t===A)break e;case W:if(i.last){c>>>=7&h,h-=7&h,i.mode=le;break}for(;h<3;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}switch(i.last=1&c,c>>>=1,h-=1,3&c){case 0:i.mode=J;break;case 1:if(d(i),i.mode=ie,t===A){c>>>=2,h-=2;break e}break;case 2:i.mode=$;break;case 3:e.msg="invalid block type",i.mode=ce}c>>>=2,h-=2;break;case J:for(c>>>=7&h,h-=7&h;h<32;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if((65535&c)!==(c>>>16^65535)){e.msg="invalid stored block lengths",i.mode=ce;break}if(i.length=65535&c,c=0,h=0,i.mode=Q,t===A)break e;case Q:i.mode=V;case V:if(m=i.length){if(m>f&&(m=f),m>l&&(m=l),0===m)break e;_.arraySet(r,a,o,m,s),f-=m,o+=m,l-=m,s+=m,i.length-=m;break}i.mode=X;break;case $:for(;h<14;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(i.nlen=(31&c)+257,c>>>=5,h-=5,i.ndist=(31&c)+1,c>>>=5,h-=5,i.ncode=(15&c)+4,c>>>=4,h-=4,i.nlen>286||i.ndist>30){e.msg="too many length or distance symbols",i.mode=ce;break}i.have=0,i.mode=ee;case ee:for(;i.have<i.ncode;){for(;h<3;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}i.lens[Ae[i.have++]]=7&c,c>>>=3,h-=3}for(;i.have<19;)i.lens[Ae[i.have++]]=0;if(i.lencode=i.lendyn,i.lenbits=7,Se={bits:i.lenbits},ye=x(y,i.lens,0,19,i.lencode,0,i.work,Se),i.lenbits=Se.bits,ye){e.msg="invalid code lengths set",i.mode=ce;break}i.have=0,i.mode=te;case te:for(;i.have<i.nlen+i.ndist;){for(;Be=i.lencode[c&(1<<i.lenbits)-1],me=Be>>>24,ke=Be>>>16&255,_e=65535&Be,!(me<=h);){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(_e<16)c>>>=me,h-=me,i.lens[i.have++]=_e;else{if(16===_e){for(Ee=me+2;h<Ee;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(c>>>=me,h-=me,0===i.have){e.msg="invalid bit length repeat",i.mode=ce;break}xe=i.lens[i.have-1],m=3+(3&c),c>>>=2,h-=2}else if(17===_e){for(Ee=me+3;h<Ee;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}c>>>=me,h-=me,xe=0,m=3+(7&c),c>>>=3,h-=3}else{for(Ee=me+7;h<Ee;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}c>>>=me,h-=me,xe=0,m=11+(127&c),c>>>=7,h-=7}if(i.have+m>i.nlen+i.ndist){e.msg="invalid bit length repeat",i.mode=ce;break}for(;m--;)i.lens[i.have++]=xe}}if(i.mode===ce)break;if(0===i.lens[256]){e.msg="invalid code -- missing end-of-block",i.mode=ce;break}if(i.lenbits=9,Se={bits:i.lenbits},ye=x(S,i.lens,0,i.nlen,i.lencode,0,i.work,Se),i.lenbits=Se.bits,ye){e.msg="invalid literal/lengths set",i.mode=ce;break}if(i.distbits=6,i.distcode=i.distdyn,Se={bits:i.distbits},ye=x(E,i.lens,i.nlen,i.ndist,i.distcode,0,i.work,Se),i.distbits=Se.bits,ye){e.msg="invalid distances set",i.mode=ce;break}if(i.mode=ie,t===A)break e;case ie:i.mode=ne;case ne:if(f>=6&&l>=258){e.next_out=s,e.avail_out=l,e.next_in=o,e.avail_in=f,i.hold=c,i.bits=h,p(e,w),s=e.next_out,r=e.output,l=e.avail_out,o=e.next_in,a=e.input,f=e.avail_in,c=i.hold,h=i.bits,i.mode===X&&(i.back=-1);break}for(i.back=0;Be=i.lencode[c&(1<<i.lenbits)-1],me=Be>>>24,ke=Be>>>16&255,_e=65535&Be,!(me<=h);){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(ke&&0===(240&ke)){for(ge=me,ve=ke,pe=_e;Be=i.lencode[pe+((c&(1<<ge+ve)-1)>>ge)],me=Be>>>24,ke=Be>>>16&255,_e=65535&Be,!(ge+me<=h);){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}c>>>=ge,h-=ge,i.back+=ge}if(c>>>=me,h-=me,i.back+=me,i.length=_e,0===ke){i.mode=fe;break}if(32&ke){i.back=-1,i.mode=X;break}if(64&ke){e.msg="invalid literal/length code",i.mode=ce;break}i.extra=15&ke,i.mode=ae;case ae:if(i.extra){for(Ee=i.extra;h<Ee;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}i.length+=c&(1<<i.extra)-1,c>>>=i.extra,h-=i.extra,i.back+=i.extra}i.was=i.length,i.mode=re;case re:for(;Be=i.distcode[c&(1<<i.distbits)-1],me=Be>>>24,ke=Be>>>16&255,_e=65535&Be,!(me<=h);){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(0===(240&ke)){for(ge=me,ve=ke,pe=_e;Be=i.distcode[pe+((c&(1<<ge+ve)-1)>>ge)],me=Be>>>24,ke=Be>>>16&255,_e=65535&Be,!(ge+me<=h);){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}c>>>=ge,h-=ge,i.back+=ge}if(c>>>=me,h-=me,i.back+=me,64&ke){e.msg="invalid distance code",i.mode=ce;break}i.offset=_e,i.extra=15&ke,i.mode=oe;case oe:if(i.extra){for(Ee=i.extra;h<Ee;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}i.offset+=c&(1<<i.extra)-1,c>>>=i.extra,h-=i.extra,i.back+=i.extra}if(i.offset>i.dmax){e.msg="invalid distance too far back",i.mode=ce;break}i.mode=se;case se:if(0===l)break e;if(m=w-l,i.offset>m){if(m=i.offset-m,m>i.whave&&i.sane){e.msg="invalid distance too far back",i.mode=ce;break}m>i.wnext?(m-=i.wnext,k=i.wsize-m):k=i.wnext-m,m>i.length&&(m=i.length),we=i.window}else we=r,k=s-i.offset,m=i.length;m>l&&(m=l),l-=m,i.length-=m;do r[s++]=we[k++];while(--m);0===i.length&&(i.mode=ne);break;case fe:if(0===l)break e;r[s++]=i.length,l--,i.mode=ne;break;case le:if(i.wrap){for(;h<32;){if(0===f)break e;f--,c|=a[o++]<<h,h+=8}if(w-=l,e.total_out+=w,i.total+=w,w&&(e.adler=i.check=i.flags?v(i.check,r,w,s-w):g(i.check,r,w,s-w)),w=l,(i.flags?c:n(c))!==i.check){e.msg="incorrect data check",i.mode=ce;break}c=0,h=0}i.mode=de;case de:if(i.wrap&&i.flags){for(;h<32;){if(0===f)break e;f--,c+=a[o++]<<h,h+=8}if(c!==(4294967295&i.total)){e.msg="incorrect length check",i.mode=ce;break}c=0,h=0}i.mode=ue;case ue:ye=R;break e;case ce:ye=O;break e;case he:return I;case be:default:return C}return e.next_out=s,e.avail_out=l,e.next_in=o,e.avail_in=f,i.hold=c,i.bits=h,(i.wsize||w!==e.avail_out&&i.mode<ce&&(i.mode<le||t!==B))&&u(e,e.output,e.next_out,w-e.avail_out)?(i.mode=he,I):(b-=e.avail_in,w-=e.avail_out,e.total_in+=b,e.total_out+=w,i.total+=w,i.wrap&&w&&(e.adler=i.check=i.flags?v(i.check,r,w,e.next_out-w):g(i.check,r,w,e.next_out-w)),e.data_type=i.bits+(i.last?64:0)+(i.mode===X?128:0)+(i.mode===ie||i.mode===Q?256:0),(0===b&&0===w||t===B)&&ye===z&&(ye=T),ye)}function h(e){if(!e||!e.state)return C;var t=e.state;return t.window&&(t.window=null),e.state=null,z}function b(e,t){var i;return e&&e.state?(i=e.state,0===(2&i.wrap)?C:(i.head=t,t.done=!1,z)):C}function w(e,t){var i,n,a,r=t.length;return e&&e.state?(i=e.state,0!==i.wrap&&i.mode!==G?C:i.mode===G&&(n=1,n=g(n,t,r,0),n!==i.check)?O:(a=u(e,t,r,r))?(i.mode=he,I):(i.havedict=1,z)):C}var m,k,_=e("../utils/common"),g=e("./adler32"),v=e("./crc32"),p=e("./inffast"),x=e("./inftrees"),y=0,S=1,E=2,B=4,Z=5,A=6,z=0,R=1,N=2,C=-2,O=-3,I=-4,T=-5,U=8,D=1,F=2,L=3,H=4,M=5,j=6,K=7,P=8,Y=9,q=10,G=11,X=12,W=13,J=14,Q=15,V=16,$=17,ee=18,te=19,ie=20,ne=21,ae=22,re=23,oe=24,se=25,fe=26,le=27,de=28,ue=29,ce=30,he=31,be=32,we=852,me=592,ke=15,_e=ke,ge=!0;i.inflateReset=o,i.inflateReset2=s,i.inflateResetKeep=r,i.inflateInit=l,i.inflateInit2=f,i.inflate=c,i.inflateEnd=h,i.inflateGetHeader=b,i.inflateSetDictionary=w,i.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":1,"./adler32":3,"./crc32":5,"./inffast":7,"./inftrees":9}],9:[function(e,t,i){"use strict";var n=e("../utils/common"),a=15,r=852,o=592,s=0,f=1,l=2,d=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],u=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],c=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],h=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];t.exports=function(e,t,i,b,w,m,k,_){var g,v,p,x,y,S,E,B,Z,A=_.bits,z=0,R=0,N=0,C=0,O=0,I=0,T=0,U=0,D=0,F=0,L=null,H=0,M=new n.Buf16(a+1),j=new n.Buf16(a+1),K=null,P=0;for(z=0;z<=a;z++)M[z]=0;for(R=0;R<b;R++)M[t[i+R]]++;for(O=A,C=a;C>=1&&0===M[C];C--);if(O>C&&(O=C),0===C)return w[m++]=20971520,w[m++]=20971520,_.bits=1,0;for(N=1;N<C&&0===M[N];N++);for(O<N&&(O=N),U=1,z=1;z<=a;z++)if(U<<=1,U-=M[z],U<0)return-1;if(U>0&&(e===s||1!==C))return-1;for(j[1]=0,z=1;z<a;z++)j[z+1]=j[z]+M[z];for(R=0;R<b;R++)0!==t[i+R]&&(k[j[t[i+R]]++]=R);if(e===s?(L=K=k,S=19):e===f?(L=d,H-=257,K=u,P-=257,S=256):(L=c,K=h,S=-1),F=0,R=0,z=N,y=m,I=O,T=0,p=-1,D=1<<O,x=D-1,e===f&&D>r||e===l&&D>o)return 1;for(var Y=0;;){Y++,E=z-T,k[R]<S?(B=0,Z=k[R]):k[R]>S?(B=K[P+k[R]],Z=L[H+k[R]]):(B=96,Z=0),g=1<<z-T,v=1<<I,N=v;do v-=g,w[y+(F>>T)+v]=E<<24|B<<16|Z|0;while(0!==v);for(g=1<<z-1;F&g;)g>>=1;if(0!==g?(F&=g-1,F+=g):F=0,R++,0===--M[z]){if(z===C)break;z=t[i+k[R]]}if(z>O&&(F&x)!==p){for(0===T&&(T=O),y+=N,I=z-T,U=1<<I;I+T<C&&(U-=M[I+T],!(U<=0));)I++,U<<=1;if(D+=1<<I,e===f&&D>r||e===l&&D>o)return 1;p=F&x,w[p]=O<<24|I<<16|y-m|0}}return 0!==F&&(w[y+F]=z-T<<24|64<<16|0),_.bits=O,0}},{"../utils/common":1}],10:[function(e,t,i){"use strict";t.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],11:[function(e,t,i){"use strict";function n(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}t.exports=n},{}],"/lib/inflate.js":[function(e,t,i){"use strict";function n(e){if(!(this instanceof n))return new n(e);this.options=s.assign({chunkSize:16384,windowBits:0,to:""},e||{});var t=this.options;t.raw&&t.windowBits>=0&&t.windowBits<16&&(t.windowBits=-t.windowBits,0===t.windowBits&&(t.windowBits=-15)),!(t.windowBits>=0&&t.windowBits<16)||e&&e.windowBits||(t.windowBits+=32),t.windowBits>15&&t.windowBits<48&&0===(15&t.windowBits)&&(t.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var i=o.inflateInit2(this.strm,t.windowBits);if(i!==l.Z_OK)throw new Error(d[i]);this.header=new c,o.inflateGetHeader(this.strm,this.header)}function a(e,t){var i=new n(t);if(i.push(e,!0),i.err)throw i.msg;return i.result}function r(e,t){return t=t||{},t.raw=!0,a(e,t)}var o=e("./zlib/inflate"),s=e("./utils/common"),f=e("./utils/strings"),l=e("./zlib/constants"),d=e("./zlib/messages"),u=e("./zlib/zstream"),c=e("./zlib/gzheader"),h=Object.prototype.toString;n.prototype.push=function(e,t){var i,n,a,r,d,u,c=this.strm,b=this.options.chunkSize,w=this.options.dictionary,m=!1;if(this.ended)return!1;n=t===~~t?t:t===!0?l.Z_FINISH:l.Z_NO_FLUSH,"string"==typeof e?c.input=f.binstring2buf(e):"[object ArrayBuffer]"===h.call(e)?c.input=new Uint8Array(e):c.input=e,c.next_in=0,c.avail_in=c.input.length;do{if(0===c.avail_out&&(c.output=new s.Buf8(b),c.next_out=0,c.avail_out=b),i=o.inflate(c,l.Z_NO_FLUSH),i===l.Z_NEED_DICT&&w&&(u="string"==typeof w?f.string2buf(w):"[object ArrayBuffer]"===h.call(w)?new Uint8Array(w):w,i=o.inflateSetDictionary(this.strm,u)),i===l.Z_BUF_ERROR&&m===!0&&(i=l.Z_OK,m=!1),i!==l.Z_STREAM_END&&i!==l.Z_OK)return this.onEnd(i),this.ended=!0,!1;c.next_out&&(0!==c.avail_out&&i!==l.Z_STREAM_END&&(0!==c.avail_in||n!==l.Z_FINISH&&n!==l.Z_SYNC_FLUSH)||("string"===this.options.to?(a=f.utf8border(c.output,c.next_out),r=c.next_out-a,d=f.buf2string(c.output,a),c.next_out=r,c.avail_out=b-r,r&&s.arraySet(c.output,c.output,a,r,0),this.onData(d)):this.onData(s.shrinkBuf(c.output,c.next_out)))),0===c.avail_in&&0===c.avail_out&&(m=!0)}while((c.avail_in>0||0===c.avail_out)&&i!==l.Z_STREAM_END);return i===l.Z_STREAM_END&&(n=l.Z_FINISH),n===l.Z_FINISH?(i=o.inflateEnd(this.strm),this.onEnd(i),this.ended=!0,i===l.Z_OK):n!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),c.avail_out=0,!0)},n.prototype.onData=function(e){this.chunks.push(e)},n.prototype.onEnd=function(e){e===l.Z_OK&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=s.flattenChunks(this.chunks)),this.chunks=[],this.err=e,this.msg=this.strm.msg},i.Inflate=n,i.inflate=a,i.inflateRaw=r,i.ungzip=a},{"./utils/common":1,"./utils/strings":2,"./zlib/constants":4,"./zlib/gzheader":6,"./zlib/inflate":8,"./zlib/messages":10,"./zlib/zstream":11}]},{},[])("/lib/inflate.js")});

const decoder = new TextDecoder('utf-8');
const utf8Strict = new TextDecoder('utf-8',{fatal:true});
function repairText(value){
 if(typeof value!=='string'||!/[ÃÂâ]/.test(value))return value;
 // Meta exports sometimes contain UTF-8 bytes misread as Latin-1 ("já" -> "jÃ¡").
 return value.replace(/(?:Ã[\u0080-\u00BF]|Â[\u0080-\u00BF]|â[\u0080-\u00BF]{2})+/g,chunk=>{
  try {const bytes=Uint8Array.from(chunk,ch=>ch.charCodeAt(0));return utf8Strict.decode(bytes);} catch {return chunk;}
 });
}

const banned = /(?:^|[\/ _-])(messages?|chats?|direct.messages?|inbox|contacts?|passwords?|security|payment|payments|purchases?|credit.card|cookies?|addresses|locations?|autofill|login_history|device_information)(?:[\/ _.-]|$)/i;
const norm = x => String(x || '').toLowerCase().replace(/[^a-z0-9]+/g, '_');
function dateValue(v){
 if(v == null || v === '')return null;
 if(typeof v==='number'){let n=v<1e11?v*1000:v; return Number.isFinite(n)&&n>0 ? new Date(n) : null;}
 if(typeof v==='string'){
  let x=v.trim(); if(/^\d{10,13}$/.test(x))return dateValue(Number(x));
  if(/^\d{4}-\d\d-\d\d \d\d:\d\d/.test(x)) x=x.replace(' ','T')+(x.includes('Z')||/[+-]\d\d:?\d\d$/.test(x)?'':'Z');
  const d=new Date(x);return Number.isFinite(d.getTime())?d:null;
 } return null;
}
function timeFromRecord(r){
 for(const key of ['timestamp','creation_timestamp','taken_at','date','Date','time','Time','ts','endTime','end_time','created_at','creation_time','creation_date']){
  if(r[key]!=null){const d=dateValue(r[key]);if(d)return d.toISOString();}
 }
 for(const d of (r.string_list_data || [])){if(d.timestamp!=null){const x=dateValue(d.timestamp);if(x)return x.toISOString();}}
 for(const v of Object.values(r.string_map_data||{})){const x=dateValue(v?.timestamp);if(x)return x.toISOString();}
 for(const v of Object.values(r.media_metadata||{})){const x=dateValue(v?.timestamp);if(x)return x.toISOString();}
 // Instagram exports single-image feed posts without a top-level timestamp.
 // Their actual publication time is on media[0].creation_timestamp.
 if(Array.isArray(r.media)){
  const dates=r.media.map(m=>dateValue(m?.creation_timestamp??m?.taken_at??m?.timestamp)).filter(Boolean);
  if(dates.length)return new Date(Math.min(...dates.map(d=>d.getTime()))).toISOString();
 }
 return null;
}
function zipEntries(file){
 return file.slice(Math.max(0,file.size-66000)).arrayBuffer().then(async tail=>{
   const b=new DataView(tail);let idx=-1;
   for(let i=b.byteLength-22;i>=0;i--){if(b.getUint32(i,true)===0x06054b50){idx=i;break;}}
   if(idx<0)throw Error('Não foi possível ler a estrutura do ZIP. Verifique se está completo.');
   const count=b.getUint16(idx+10,true),size=b.getUint32(idx+12,true),offset=b.getUint32(idx+16,true);
   if(count===65535||offset===4294967295)throw Error('ZIP64 ainda não é suportado. Exporte em partes menores.');
   if(size>96*1024*1024)throw Error('Índice do ZIP grande demais para leitura segura.');
   const central=new DataView(await file.slice(offset,offset+size).arrayBuffer());const list=[];let pos=0;
   for(let i=0;i<count;i++){
    if(pos+46>central.byteLength||central.getUint32(pos,true)!==0x02014b50)throw Error('Índice ZIP inválido.');
    const method=central.getUint16(pos+10,true),compressed=central.getUint32(pos+20,true),uncompressed=central.getUint32(pos+24,true);
    const nameLen=central.getUint16(pos+28,true),extra=central.getUint16(pos+30,true),comment=central.getUint16(pos+32,true),local=central.getUint32(pos+42,true);
    const name=decoder.decode(new Uint8Array(central.buffer,pos+46,nameLen));
    list.push({name,method,compressed,uncompressed,local});pos+=46+nameLen+extra+comment;
   }
   return list;
 });
}
async function zipText(file,e){
 if(e.uncompressed>260*1024*1024||e.compressed>260*1024*1024)throw Error('JSON individual excede o limite de 260 MB; exporte somente atividades.');
 const header=new DataView(await file.slice(e.local,e.local+30).arrayBuffer());
 if(header.getUint32(0,true)!==0x04034b50)throw Error('Entrada ZIP inválida.');
 const start=e.local+30+header.getUint16(26,true)+header.getUint16(28,true);
 const data=new Uint8Array(await file.slice(start,start+e.compressed).arrayBuffer());
 if(e.method===0)return decoder.decode(data);
 if(e.method===8)return decoder.decode(self.pako.inflateRaw(data));
 throw Error('Formato de compressão ZIP não suportado.');
}
function igCategory(path,root){
 // First distinguish interactions from media published by the user.
 const base=String(path).split('/').pop().toLowerCase();
 const k=norm(path+'_'+Object.keys(root||{}).slice(0,4).join('_'));
 if(/liked_posts|liked_comments|likes_media_likes|likes_comment_likes|likes_post_likes/.test(k))return 'likes';
 if(/saved_posts|saved_reels|saved_saved_media|saved_saved_reels|saved_saved_posts/.test(k))return 'saved';
 if(/post_comments|comments_media_comments|reel_comments/.test(k))return 'comments';
 if(/story_reactions|stories_liked|story_likes|story_interactions/.test(k))return 'stories';
 if(/followers_1|followers_json|relationships_followers/.test(k))return 'followers';
 if(/following_json|relationships_following/.test(k))return 'following';
 if(/videos_watched|watch_history|reels_watched/.test(k))return 'watched';
 if(/shared_posts|share_history|reposts|shares\.json/.test(k))return 'shares';
 if(/recent_searches|searches|search_history/.test(k) && /search/.test(base))return 'searches';
 // Only media manifests; avoid other_content, archive and collections.
 if(/^reels?(?:_\d+)?\.json$/.test(base)||/^ig_reels?(?:_\d+)?\.json$/.test(base))return 'reels';
 if(/^stories(?:_\d+)?\.json$/.test(base)||/^ig_stories(?:_\d+)?\.json$/.test(base))return 'storyPosts';
 if(/^posts(?:_\d+)?\.json$/.test(base)||/^ig_posts(?:_\d+)?\.json$/.test(base))return 'posts';
 return null;
}
function findIGRecords(root,category){
 if(Array.isArray(root))return root;
 if(!root||typeof root!=='object')return [];
 if(Array.isArray(root.media)&&root.media.length)return [root];
 const arr=[];
 const preferred=category==='posts'?/^(ig_posts|posts)$/i:category==='reels'?/^(ig_reels|reels)$/i:category==='storyPosts'?/^(ig_stories|stories)$/i:null;
 if(preferred){for(const [k,v] of Object.entries(root))if(preferred.test(k)&&Array.isArray(v))arr.push(...v);if(arr.length)return arr;}
 for(const [k,v] of Object.entries(root)){
  if(!Array.isArray(v)||/string_list_data|media_metadata|label_values/.test(k))continue;
  if(v.length&&typeof v[0]==='object')arr.push(...v);
 }
 return arr;
}
const kinds=['watched','likes','saved','shares','comments','posts','reels','storyPosts','following','followers','searches','stories','downvotes','listens','podcasts'];
let events=[], seen=new Set(), skipped=0, parseErrors=0, scanned=0, dedup=new Set(), account=new Map(), sources=[];
function add(type, date, label='', duration=0, meta='', uniqueId=''){
 if(!kinds.includes(type))return;
 const valid=date?dateValue(date):null;
 const stamp=valid?valid.toISOString():null;
 const ev={type,time:stamp,duration:Number(duration)||0,label:typeof label==='string'?repairText(label).slice(0,type==='comments'?1800:180):'',meta:typeof meta==='string'?meta.slice(0,120):''};
 // Media items are deduplicated by their media URI/ID and date across manifests.
 const key=[type,stamp,uniqueId||ev.label,ev.meta,ev.duration].join('|');
 if(dedup.has(key))return;dedup.add(key);events.push(ev);seen.add(type);
}
function igPublicationType(record,category){
 if(!['posts','reels','storyPosts'].includes(category))return category;
 if(category!=='posts')return category;
 const media=Array.isArray(record.media)?record.media:[];
 const desc=[record.media_type,record.product_type,record.productType,record.type,...media.map(m=>m?.media_type),...media.map(m=>m?.product_type),...media.map(m=>m?.uri),record.uri].filter(x=>typeof x==='string').join(' ').toLowerCase();
 return /\b(reels?|clips)\b|\/(?:reels?|clips)\//.test(desc)?'reels':'posts';
}
function igMediaId(record){
 const media=Array.isArray(record.media)?record.media:[];
 const one=media.find(m=>typeof m?.uri==='string'&&m.uri);
 return String(record.fbid||record.media_id||record.id||record.uri||one?.uri||'');
}
function parseInstagram(name,root){
 const category=igCategory(name,root);if(!category)return;
 seen.add(category);
 for(const r of findIGRecords(root,category)){
  if(!r||typeof r!=='object')continue;
  const type=igPublicationType(r,category);
  const media=Array.isArray(r.media)?r.media:[];
  const fromMap=r.string_map_data||{};
  const commentValue=fromMap.Comment?.value||fromMap.comment?.value||fromMap.Text?.value||fromMap.text?.value||r.comment||r.text||r.content||'';
  const label=type==='comments'?(commentValue||r.title||''):(r.title||r.username||r.name||media[0]?.title||media[0]?.caption||'');
  // One event per published entry; a carousel with multiple media is still one post.
  add(type,timeFromRecord(r),label,0,'',igMediaId(r));
 }
}
function tiktokCat(path){
 const p=norm(path);
 if(/video_browsing_history|watch_history|watchhistory/.test(p))return 'watched';
 if(/like_list|likes_list|liked_videos/.test(p))return 'likes';
 if(/favourite_videos|favorite_videos|favorites_list|favorite_list/.test(p))return 'saved';
 if(/share_history|sharing_history/.test(p))return 'shares';
 if(/comment_history|comment_list/.test(p))return 'comments';
 if(/search_history|searches/.test(p))return 'searches';
 if(/following_list/.test(p))return 'following';
 if(/follower_list/.test(p))return 'followers';
 if(/posts_list|my_posts/.test(p))return 'posts';
 return null;
}
function parseTikTok(name,root){
 function walk(v,path,depth){
  if(depth>9||v==null||typeof v!=='object')return;
  if(Array.isArray(v)){
   const kind=tiktokCat(path);if(kind){seen.add(kind);for(const r of v){if(r&&typeof r==='object')add(kind,timeFromRecord(r),r.Title||r.Link||r['Video Link']||r.Username||r['Post title']||'');}return;}
   for(const sub of v.slice(0,250000)) if(sub&&typeof sub==='object'&&!Array.isArray(sub))walk(sub,path,depth+1);
  } else {
   for(const [key,val] of Object.entries(v)){
    if(banned.test(key))continue;
    const p=path+'/'+key;
    if(Array.isArray(val)&&tiktokCat(p)){
     const kind=tiktokCat(p);seen.add(kind);for(const r of val){if(r&&typeof r==='object')add(kind,timeFromRecord(r),r.Title||r.Link||r['Video Link']||r.Username||'');}
    }else if(typeof val==='object')walk(val,p,depth+1);
   }
  }
 }
 walk(root,name,0);
}
function parseYouTube(name,root){
 if(!Array.isArray(root))return;
 const path=norm(name);
 if(/watch_history|watch_history_json/.test(path)){
  seen.add('watched');for(const r of root){if(r&&typeof r==='object'&&!(r.title||'').toLowerCase().startsWith('searched')) add('watched',r.time||r.date,r.title||'');}
 }else if(/search_history/.test(path)){
  seen.add('searches');for(const r of root){if(r&&typeof r==='object')add('searches',r.time||r.date,'');}
 }
}
function parseCSV(text,visit){
 let cols=[],cell='',quoted=false,head=null;
 text=text.replace(/^\uFEFF/,'');
 const emit=()=>{
  cols.push(cell);cell='';
  if(!head){head=cols.map(v=>String(v||'').trim().replace(/^\uFEFF/,''));}
  else if(cols.some(c=>c.trim())){
   const row={};head.forEach((key,i)=>{if(key)row[key]=cols[i]||'';});visit(row);
  }
  cols=[];
 };
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(c==='"')quoted=false;else cell+=c;}
  else if(c==='"'&&cell==='')quoted=true;
  else if(c===',') {cols.push(cell);cell='';}
  else if(c==='\n'){emit();}
  else if(c==='\r'){if(text[i+1]==='\n')i++;emit();}
  else cell+=c;
 }
 if(cell||cols.length)emit();
}
function redditCategory(path){
 const base=String(path).split('/').pop().toLowerCase();
 if(base==='posts.csv')return 'posts';
 if(base==='comments.csv')return 'comments';
 if(/^(saved_posts|saved_comments)\.csv$/.test(base))return 'saved';
 if(/^(upvoted_posts|upvoted_comments)\.csv$/.test(base))return 'likes';
 if(/^(downvoted_posts|downvoted_comments)\.csv$/.test(base))return 'downvotes';
 if(/^(post_votes|comment_votes)\.csv$/.test(base))return 'votes';
 return null;
}
function parseReddit(name,text){
 const kind=redditCategory(name);if(!kind)return;
 if(text.length>50*1024*1024)throw Error('CSV muito grande. Separe arquivos menores antes de importar.');
 if(kind!=='votes')seen.add(kind);
 parseCSV(text,r=>{
  const obj=Object.fromEntries(Object.entries(r).map(([k,v])=>[k.toLowerCase().trim().replace(/[^a-z0-9]+/g,'_'),v]));
  const vote=String(obj.direction||obj.vote||obj.vote_direction||obj.vote_type||obj.vote_value||'').toLowerCase();
  const type=kind==='votes' ? (/down|^-1$|false/.test(vote)?'downvotes':/up|^1$|true/.test(vote)?'likes':null) :kind;
  if(!type)return;
  seen.add(type);
  const date=obj.created_utc||obj.created_at||obj.creation_date||obj.date||obj.timestamp||obj.time||obj.created||'';
  const label= type==='comments' ? (obj.body||obj.comment||obj.text||obj.content||'') :(obj.title||obj.permalink||obj.url||obj.id||'');
  const unique=String(obj.id||obj.permalink||obj.url||obj.post_id||obj.comment_id||'');
  // Votes/saves may not contain action timestamps in Reddit exports.
  // Keep undated totals separate; never assign them to the chosen year.
  add(type,date,label,0,'',unique||label);
 });
}

// Spotify: accepts official basic StreamingHistory*.json and Extended Streaming History JSON.
// ms_played is playback duration, not a full-track count or time spent in the app.
function parseSpotify(name,root){
 if(!Array.isArray(root))return;
 const validFile=/^(streaming_history|streaminghistory|endsong|end_song)/.test(norm(name.split('/').pop()));
 if(!validFile)return;
 for(const item of root){
  if(!item||typeof item!=='object')continue;
  const time=timeFromRecord(item);
  const isPodcast=!!(item.episode_name||item.episodeName||item.spotify_episode_uri);
  const track=isPodcast?(item.episode_name||item.episodeName):(item.master_metadata_track_name||item.trackName||item.track_name);
  const artist=isPodcast?(item.episode_show_name||item.episodeShowName||''):(item.master_metadata_album_artist_name||item.artistName||'');
  const rawMs=item.ms_played??item.msPlayed;
  if(!time||typeof track!=='string'||!track.trim())continue;
  const duration=Number(rawMs);
  if(rawMs!==undefined&&(!Number.isFinite(duration)||duration<0||duration>24*60*60*1000))continue;
  add(isPodcast?'podcasts':'listens',time,track,rawMs===undefined?0:duration,String(artist||''),String(item.spotify_track_uri||item.spotify_episode_uri||''));
  if(rawMs!==undefined)seen.add('minutes');
 }
}
// Facebook export manifests change over time. Recognize only identifiable activity
// files and dated records; never estimate reach, impressions or reactions from posts.
function facebookCategory(path){
 const base=norm(String(path).split('/').pop());
 if(/^(your_posts|posts)(_[0-9]+)?_json$/.test(base))return 'posts';
 if(/^(your_comments|comments)(_[0-9]+)?_json$/.test(base))return 'comments';
 if(/^(your_likes_and_reactions|likes_and_reactions|reactions)(_[0-9]+)?_json$/.test(base))return 'likes';
 if(/^(saved_items|your_saved_items|saved_posts)(_[0-9]+)?_json$/.test(base))return 'saved';
 return null;
}
function parseFacebook(name,root){
 const kind=facebookCategory(name);if(!kind)return;
 const arrays=[];
 if(Array.isArray(root))arrays.push(root);
 else if(root&&typeof root==='object'){
  for(const [key,value] of Object.entries(root)){
   if(banned.test(key))continue;
   if(Array.isArray(value)&&/post|comment|react|like|sav/i.test(key))arrays.push(value);
  }
 }
 if(!arrays.length)return;
 seen.add(kind);
 for(const arr of arrays)for(const r of arr){
  if(!r||typeof r!=='object')continue;
  const timestamp=timeFromRecord(r);
  if(!timestamp)continue;
  const data=Array.isArray(r.data)?r.data:[];
  const first=data.find(x=>x&&typeof x==='object')||{};
  const text=first.post||first.comment||first.text||r.title||r.description||r.comment||r.text||'';
  add(kind,timestamp,typeof text==='string'?text:'',0,'',String(r.id||r.fbid||r.uri||''));
 }
}
function supportedFile(platform,name){
 const x=name.toLowerCase();
 if(banned.test(x))return false;
 if(platform==='reddit')return redditCategory(x)!==null;
 if(platform==='spotify')return x.endsWith('.json')&&/^(streaming_history|streaminghistory|endsong|end_song)/.test(norm(x.split('/').pop()));
 if(platform==='facebook')return x.endsWith('.json')&&facebookCategory(x)!==null;
 if(!x.endsWith('.json'))return false;
 if(platform==='instagram')return /likes|liked|saved|comments|story_interactions|stories_liked|following|followers|posts|reels|stories|video|search|share|repost/.test(x);
 if(platform==='tiktok')return true;
 if(platform==='youtube')return /watch.history|search.history/.test(x);
 return false;
}
function consume(platform,name,content){
 if(platform==='reddit'){parseReddit(name,content);scanned++;return;}
 let obj;try{obj=JSON.parse(content.replace(/^\uFEFF/,''));}catch(err){parseErrors++;return;}
 if(platform==='instagram')parseInstagram(name,obj);
 if(platform==='tiktok')parseTikTok(name,obj);
 if(platform==='youtube')parseYouTube(name,obj);
 if(platform==='spotify')parseSpotify(name,obj);
 if(platform==='facebook')parseFacebook(name,obj);
 scanned++;
}
// Only infer when the archive contains unmistakable platform-specific filenames.
// Ambiguous posts.json/likes.json are never guessed as Meta or Reddit data.
function detectPlatform(names){
 const scores=new Set();
 for(const raw of names){
  const path=String(raw).toLowerCase(),base=path.split('/').pop();
  if(/your_instagram_activity|instagram_activity|ig_posts|likes_media_likes/.test(path))scores.add('instagram');
  if(/(^|\/)user_data\.json$/.test(path)||/video_browsing_history/.test(path))scores.add('tiktok');
  if(/youtube|takeout\/.*watch.history|watch.history\.json/.test(path))scores.add('youtube');
  if(/^(comments|posts|upvoted_posts|saved_posts|post_votes)\.csv$/.test(base))scores.add('reddit');
  if(/^(streaminghistory|streaming_history_|endsong|end_song)/.test(base))scores.add('spotify');
  if(/^(your_posts|your_comments|your_likes_and_reactions|saved_items)(_[0-9]+)?\.json$/.test(base)||/your_facebook_activity/.test(path))scores.add('facebook');
 }
 return scores.size===1?[...scores][0]:null;
}
self.onmessage=async e=>{
 if(e.data?.action!=='analyze')return;
 ({events,seen,skipped,parseErrors,scanned,dedup,account,sources}={events:[],seen:new Set(),skipped:0,parseErrors:0,scanned:0,dedup:new Set(),account:new Map(),sources:[]});
 const {files}=e.data;const requested=e.data.platform;let platform=requested;
 try{
  const discovered=[];
  for(const file of files){
   if(/\.zip$/i.test(file.name)){
    const entries=await zipEntries(file);
    for(const entry of entries)discovered.push({file,entry,name:entry.name});
   }else discovered.push({file,name:file.name});
  }
  let jobs=discovered.filter(x=>supportedFile(platform,x.name));
  if(!jobs.length){
   const detected=detectPlatform(discovered.map(j=>j.name));
   if(detected&&detected!==requested){platform=detected;jobs=discovered.filter(x=>supportedFile(platform,x.name));}
  }
  skipped=discovered.length-jobs.length;
  if(jobs.length>3000||jobs.reduce((sum,j)=>sum+(j.entry?.uncompressed||j.file.size),0)>420*1024*1024)throw Error('A exportação contém dados demais. Selecione somente atividades ou divida o ZIP.');
  // Prefer Instagram's posts_1.json over the parallel posts.json manifest.
  // The latter may duplicate entries and contain inaccurate historical timestamps.
  const selected=jobs.filter(job=>{
   if(platform!=='instagram'||!/(?:^|\/)posts\.json$/i.test(job.name))return true;
   const base=job.name.replace(/posts\.json$/i,'');
   return !jobs.some(other=>other.file===job.file&&other.name!==job.name&&other.name.startsWith(base+'posts_')&&/posts_\d+\.json$/i.test(other.name));
  });
  // A Spotify export can include both basic and extended histories. They overlap:
  // prefer the richer extended manifests, avoiding double counting plays.
  const hasExtended=platform==='spotify'&&selected.some(j=>/^(streaming_history_|end_song|endsong)/.test(norm(j.name.split('/').pop())));
  const filtered=hasExtended?selected.filter(j=>!/^(streaminghistory)[0-9_]*_json$/.test(norm(j.name.split('/').pop()))):selected;
  for(let i=0;i<filtered.length;i++){
   const job=filtered[i];self.postMessage({kind:'progress',current:i,total:filtered.length,name:job.name});
   try{const content=job.entry?await zipText(job.file,job.entry):await job.file.text();const oldScanned=scanned;consume(platform,job.name,content);if(scanned>oldScanned)sources.push(job.name.split('/').pop().slice(0,96));}
   catch(err){parseErrors++;self.postMessage({kind:'warning',message:'Não foi possível ler '+job.name.split('/').pop()+': '+err.message});}
  }
  if(!filtered.length)throw Error('Nenhum arquivo compatível com '+platform+' foi encontrado. Exporte em JSON (ou CSV para Reddit), selecione a rede correta e confira as instruções.');
  if(!events.length)throw Error('Não encontrei registros compatíveis. Confira se escolheu a rede correta e exportou as categorias de atividade.');
  self.postMessage({kind:'result',data:{events,seen:[...seen],scanned,skipped,parseErrors,platform,autoDetected:platform!==requested,sources:[...new Set(sources)].slice(0,40),undatedCounts:events.filter(x=>!x.time).reduce((acc,e)=>{acc[e.type]=(acc[e.type]||0)+1;return acc;},{})}});
 }catch(err){self.postMessage({kind:'error',message:err.message});}
};
